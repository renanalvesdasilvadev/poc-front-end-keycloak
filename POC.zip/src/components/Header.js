import React from 'react';

const Header = () => {
    return (
        <header>
            {/* Conte�do do cabe�alho */}
        </header>
    );
};

export default Header;
