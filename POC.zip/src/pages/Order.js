import React from 'react';

const Order = () => {
    return (
        <div>
            <h2>Order</h2>
            {/* Conte�do da p�gina */}
        </div>
    );
};

export default Order;
