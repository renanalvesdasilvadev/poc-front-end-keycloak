import React from 'react';

const LogisticsOrderInvoice = (props) => {
    return (
        <div>
            <h2>LogisticsOrderInvoice</h2>
            {/* Conte�do da p�gina */}
        </div>
    );
};

export default LogisticsOrderInvoice;
