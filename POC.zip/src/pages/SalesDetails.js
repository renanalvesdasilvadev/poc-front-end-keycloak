import React from 'react';

const SalesDetails = () => {
    return (
        <div>
            <h2>SalesDetails</h2>
            {/* Conte�do da p�gina */}
        </div>
    );
};

export default SalesDetails;
