import React from 'react';

const Forbidden = () => {
    return (
        <div>
            <h2>403 - Forbidden</h2>
            {/* Conte�do da p�gina */}
        </div>
    );
};

export default Forbidden;
