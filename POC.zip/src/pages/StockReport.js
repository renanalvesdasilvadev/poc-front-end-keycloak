import React from 'react';

const StockReport = () => {
    return (
        <div>
            <h2>StockReport</h2>
            {/* Conte�do da p�gina */}
        </div>
    );
};

export default StockReport;
